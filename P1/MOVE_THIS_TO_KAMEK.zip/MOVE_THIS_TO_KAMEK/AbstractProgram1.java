public abstract class AbstractProgram1 {
    public abstract boolean isStableMatching(Matching marriage);

    public abstract Matching stableMarriageGaleShapley_locationoptimal(Matching marriage);

    public abstract Matching stableMarriageGaleShapley_employeeoptimal(Matching marriage);
}
